package kr.or.kosta.koback.model;

import java.util.Enumeration;
import java.util.Hashtable;

import kr.or.kosta.koback.server.ChatService;

/**
 * Hashtable을 이용한 방 목록 관리 추상화
 * @author 유안상
 */

public class RoomManager {
	
	private Hashtable<Integer, Room> roomList;
	private Room room;
	
	public RoomManager(){
		roomList = new Hashtable<Integer, Room>();
	}
	
	public void addRoom(String name,ChatService master, int maxUserNum){
		room = new Room(name, master, maxUserNum);
		roomList.put(room.getRoomNum(), room);
	}
	
	public void addSecretRoom(String name,ChatService master, String passwd, int maxUserNum){
		room = new Room(name, master, passwd, maxUserNum);
		roomList.put(room.getRoomNum(), room);
	}
	public void addWatingRoom(){
		room = new Room("대기실", 10000000);
		roomList.put(0, room);
	}
	
	public void removeRoom(String name){
		name = room.getName(); // getName메소드를 이용하여 방 제목을 가져옴.
		for (int i = 0; i < room.getRoomNum(); i++) {
			if (roomList.keys().equals(name)) { // 만약 roomList의 key값과 매개변수로 받은 name의 이름이 같으면
				roomList.remove(name); // 해당 방이름을 가진 방을 삭제함
			}
		}
		
	}
	
	public String getRoomList(){
		Enumeration<Integer> e = roomList.keys();
		StringBuffer roomList = new StringBuffer();
		while (e.hasMoreElements()) {
			int roomNum = (int) e.nextElement();
			roomList.append(roomNum+",");
		}
		return roomList.toString();
	}
	
}
