package kr.or.kosta.koback.model;

import java.util.Hashtable;

import kr.or.kosta.koback.server.ChatService;
/**
 * 채팅방(대기실) 객체 추상화
 * @author 유안상
 */
public class Room {
	
	public static final int MAX_ROOM = 50;
	
	private String name;
	private ChatService master;
	
	private int headCount = 0;
	private String passwd;
	private int roomNum = 1;
	private int totalRoomCount = 0;
	private int maxUserNum;
	private int nowUserNum;
	
	private Hashtable<String, ChatService> clients;
	
	/** 대기실 생성자*/
	public Room(String waitName, int maxUserNum){
		name = waitName;
		this.maxUserNum = maxUserNum;
		totalRoomCount++;
	}
	
	/** 일반방 생성자*/
	public Room(String name, ChatService master, int maxUserNum){
		this.name = name;
		this.master = master;
		this.passwd = passwd;
		this.maxUserNum = maxUserNum;
		clients.put(master.getNickName(), master);
		roomNum++;
		totalRoomCount++;
	}
	
	/** 비밀방 생성자 */
	public Room(String name,ChatService master, String passwd, int maxUserNum){
		this.name = name;
		this.master = master;
		this.passwd = passwd;
		this.maxUserNum = maxUserNum;
		clients.put(master.getNickName(), master);
		roomNum++;
		totalRoomCount++;
	}
	
	public void enterRoom(ChatService client){
		nowUserNum++;
	}
	public void leaveRoom(ChatService client){
		nowUserNum--;
	}
	public void inviteUser(String nickName){}
	public void kickUser(String nickName){}
	
	/** getter/setter 메소드 */
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPasswd() {
		return passwd;
	}
	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}
	public int getRoomNum() {
		return roomNum;
	}
	public void setRoomNum(int roomNum) {
		this.roomNum = roomNum;
	}
	public int getMaxUserNum() {
		return maxUserNum;
	}
	public void setMaxUserNum(int maxUserNum) {
		this.maxUserNum = maxUserNum;
	}
	public int getNowUserNum() {
		return nowUserNum;
	}
	public void setNowUserNum(int nowUserNum) {
		this.nowUserNum = nowUserNum;
	}
	public Hashtable<String, ChatService> getClients() {
		return clients;
	}
	public void setClients(Hashtable<String, ChatService> clients) {
		this.clients = clients;
	}
	
	public ChatService getMaster() {
		return master;
	}

	public void setMaster(ChatService master) {
		this.master = master;
	}

	public int getHeadCount() {
		return clients.size();
	}

	public void setHeadCount(int headCount) {
		this.headCount = headCount;
	}

	@Override
	public String toString() {
		return "Room [name=" + name + ", passwd=" + passwd + ", roomNum=" + roomNum + ", maxUserNum=" + maxUserNum
				+ ", nowUserNum=" + nowUserNum + ", clients=" + clients + "]";
	}
	
}
