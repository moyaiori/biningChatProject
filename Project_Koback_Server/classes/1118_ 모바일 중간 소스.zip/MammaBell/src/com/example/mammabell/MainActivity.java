package com.example.mammabell;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import com.hanshin.mammabell.schedule.ScheduleListActivity;

public class MainActivity extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		
		Handler h = new Handler();
		h.postDelayed(new splashhandler(), 1000);	//���� �ð��� �°� ���� ȭ�� ��ȯ.
	}
	
	class splashhandler implements Runnable {
		public void run() {
			startActivity(new Intent(getApplication(), ScheduleListActivity.class));
			MainActivity.this.finish();
		}
	}
}
