package com.hanshin.mammabell.regist;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

import com.example.mammabell.R;
import com.hanshin.mammabell.applist.AppActivity;

public class RegistActivity extends Activity implements OnClickListener {

	private Button btn_applist;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.regist);
		
		btn_applist = (Button) findViewById(R.id.btn_applist);
		btn_applist.setOnClickListener(this);
	}
	public void onClick(View v) {
		switch (v.getId()) {

		case R.id.btn_applist:
		//	Toast.makeText(RegistActivity.this, "testttt", Toast.LENGTH_LONG);
			startActivity(new Intent(getApplication(), AppActivity.class));
		
			break;
		}
	}
	
}
