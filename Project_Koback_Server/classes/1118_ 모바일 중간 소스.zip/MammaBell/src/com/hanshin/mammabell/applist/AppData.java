package com.hanshin.mammabell.applist;

import android.graphics.drawable.Drawable;

public class AppData {
	private Drawable image;
	private String name;
	private String packname;
	
	public AppData(Drawable image, String name, String packname) {
		this.image = image;
		this.name = name;
		this.packname = packname;
	}

	public Drawable getImage() {
		return image;
	}

	public void setImage(Drawable image) {
		this.image = image;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public String getPackName() {
		return packname;
	}

	public void setPackName(String packname) {
		this.packname = packname;
	}
}
