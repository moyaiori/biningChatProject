package com.hanshin.mammabell.applist;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.Toast;

import com.example.mammabell.R;

public class AppActivity extends Activity implements OnItemClickListener{
	private ArrayList<String> arr_appinfo;
	
	// Package ���� ����
	private PackageManager packageManager;
	private ArrayList<AppData> appList;
	private List<ResolveInfo> packageList;
	private Intent intent;
	// ListView ���� ����
	private AppAdapter appAdapter;
	private ListView appListview;
	private PackageInfo info;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.app);
		
		packageManager = this.getApplicationContext().getPackageManager();
        intent = new Intent(Intent.ACTION_MAIN, null); // ��Ű�� �Ŵ��� ȣ���� ���� Intent.ACTION_MAIN
        intent.addCategory(Intent.CATEGORY_LAUNCHER);
        packageList = packageManager.queryIntentActivities(intent, 0);  
        
        appList = new ArrayList<AppData>();

        for (ResolveInfo in : packageList) {
        	String appPackageName   = in.activityInfo.packageName;
        	String appName          = in.loadLabel(packageManager).toString();
        	Drawable drawable       = in.activityInfo.loadIcon(packageManager);
        	
        	appList.add(new AppData(drawable, appName, appPackageName));
        }
        appAdapter = new AppAdapter(this, appList);
        appListview = (ListView) findViewById(R.id.lv_applist);
        appListview.setOnItemClickListener(this);
        appListview.setAdapter(appAdapter);
	}

	@Override
	public void onItemClick(AdapterView<?> parentView, View clickedView, int pos, long id) {
		String message = appList.get(pos).getPackName();
		ArrayList<String> arr_appinfo = new ArrayList<String>();
		arr_appinfo.add(message);
		System.out.println("----------"+message+"---------");
		//���� Ŭ���� ���� ��Ű���� �ϴ�
	//	Intent intent = getPackageManager().getLaunchIntentForPackage(message);
	//	startActivity(intent);
	}
}
