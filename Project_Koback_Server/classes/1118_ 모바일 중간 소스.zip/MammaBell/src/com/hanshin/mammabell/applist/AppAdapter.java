package com.hanshin.mammabell.applist;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.mammabell.R;

public class AppAdapter extends BaseAdapter{
	private Context context; // �Ѿ�� Activity ������ ���� ����
	private LayoutInflater inflater;
	private ArrayList<AppData> arrData;

	public AppAdapter(Context c, ArrayList<AppData> arr) {
		this.arrData = arr;
		this.context = c;
		inflater = (LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	}

	public View getView(final int position, View convertView, ViewGroup parent) {
		if (convertView == null) {
			convertView = inflater.inflate(R.layout.app_row, parent, false);
		}
		
		ImageView image = (ImageView) convertView.findViewById(R.id.iv_app);
		image.setImageDrawable(arrData.get(position).getImage());

		TextView name = (TextView) convertView.findViewById(R.id.tv_appName);
		name.setText(arrData.get(position).getName());
		return convertView;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return arrData.size();
	}

	@Override
	public Object getItem(int arg0) {
		return arrData.get(arg0).getName();
	}

	@Override
	public long getItemId(int arg0) {
		return arg0;
	}
}
