package com.hanshin.mammabell.db;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class dbManager extends SQLiteOpenHelper{
	public dbManager(Context context) {
		super(context, "MammabellDB", null, 1);
	}
	
	@Override
	public void onCreate(SQLiteDatabase db) {
		db.execSQL("CREATE TABLE schedules (no INTEGER PRIMARY KEY AUTOINCREMENT," +
				"title TEXT," +
				"groups TEXT);");
		
		db.execSQL("CREATE TABLE times (no INTEGER PRIMARY KEY AUTOINCREMENT," +
				"sc_no INTEGER," +
    			"appname TEXT," +
    			"apppack TEXT," +
    			"appicon INTEGER," +
    			"time TEXT);");
	}
	
	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){}

	// ��ϵ� �������� ������ ����
	public Cursor countSchedule(SQLiteDatabase db){
        Cursor cursor = db.rawQuery("select count(no) from schedules group by no;", null);
        return cursor;
    }
	
	// ��ϵ� �������� ������ ����
	public Cursor selectSchedule(SQLiteDatabase db){
		Cursor cursor = db.rawQuery("select no, title, groups from schedules;", null);
    	return cursor;
	}
    /*
	public void insertApp(String name,String pack,String check){
    	SQLiteDatabase db  = getWritableDatabase();
        String str = "insert into Apps(appName, appPack ,appCheck) values('" + name + "','" + pack + "' ,'" + check + "');";
        // ������ �����Ѵ�.
        db.execSQL(str);
        // �����ͺ��̽���  �ݴ´�.
        db.close();
    }
     
    public Cursor selectApp(SQLiteDatabase db){
        // �����͸� �˻����ִ� ������ �����Ͽ� rawQuery �޼ҵ带 ȣ���Ѵ�.
        Cursor cursor = db.rawQuery("select appPack,appCheck,appName from Apps;", null);
        return cursor;
    }
    
    public void updateCheck(String check, String pack, String name){
    	SQLiteDatabase db  = getWritableDatabase();
    	String str = "update Apps set appCheck = '" + check + "' where appName = '" + name + "' and appPack = '" + pack + "'";
    	db.execSQL(str);
        // �����ͺ��̽���  �ݴ´�.
        db.close();
    }
    */
}
