package com.hanshin.mammabell.schedule;

public class ScheduleData {
	private int no;
	private String title;
	private String group;
	
	public ScheduleData(int no, String title, String group) {
		this.no = no;
		this.title = title;
		this.group = group;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String isGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	}

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}
}
