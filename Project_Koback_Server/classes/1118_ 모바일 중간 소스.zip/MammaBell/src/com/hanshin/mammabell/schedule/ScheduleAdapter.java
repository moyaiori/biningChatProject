package com.hanshin.mammabell.schedule;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.mammabell.R;

public class ScheduleAdapter extends BaseAdapter{
	private Context context; // �Ѿ�� Activity ������ ���� ����
	private LayoutInflater inflater;
	private ArrayList<ScheduleData> arrData;

	public ScheduleAdapter(Context c, ArrayList<ScheduleData> arr) {
		this.arrData = arr;
		this.context = c;
		inflater = (LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	}

	public View getView(final int position, View convertView, ViewGroup parent) {
		if (convertView == null) {
			convertView = inflater.inflate(R.layout.schedule_row, parent, false);
		}
		if(arrData.size() == 1 && arrData.get(position).getNo() == -1){
			TextView sub_title = (TextView) convertView.findViewById(R.id.tv_sub);
			sub_title.setText("��ϵ� �⺻ �������� �����ϴ�.");
		} else {
			TextView sub_title = (TextView) convertView.findViewById(R.id.tv_sub);
			sub_title.setText(arrData.get(position).getTitle());
		}
		return convertView;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return arrData.size();
	}

	@Override
	public Object getItem(int arg0) {
		return arrData.get(arg0).getTitle();
	}

	@Override
	public long getItemId(int arg0) {
		return arg0;
	}
}
