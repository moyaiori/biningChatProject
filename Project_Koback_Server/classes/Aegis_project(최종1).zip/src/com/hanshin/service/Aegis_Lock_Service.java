package com.hanshin.service;

import com.hanshin.lock.LockActivity;

import android.app.Activity;
import android.app.KeyguardManager;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.IBinder;
import android.widget.Toast;

public class Aegis_Lock_Service extends Service {

	private KeyguardManager km = null;
	private KeyguardManager.KeyguardLock keylock = null;
	public static int key = 0; // ��� ���� ����
	
	private BroadcastReceiver mReceiver = new BroadcastReceiver() {
		@Override
		public void onReceive(Context context, Intent intent) {			
			if (key == 1) {
				String action = intent.getAction();
				if (action.equals("android.intent.action.SCREEN_OFF")) {

					Intent i = new Intent(context, LockActivity.class);
					i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					context.startActivity(i);
				}
			}
		}
	};

	@Override
	public void onCreate() {

		km = (KeyguardManager) this.getSystemService(Activity.KEYGUARD_SERVICE);
		if (km != null) {
			keylock = km.newKeyguardLock("KEYGUARD_SERVICE");
			keylock.disableKeyguard();
		}

		super.onCreate();
	}

	@Override
	public void onDestroy() {

		super.onDestroy();
		km = (KeyguardManager) this.getSystemService(Activity.KEYGUARD_SERVICE);
		if (km != null) {
			keylock = km.newKeyguardLock("KEYGUARD_SERVICE");
			keylock.disableKeyguard();
		}
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		Toast.makeText(this, "���񽺰� ���۵Ǿ����ϴ�.", Toast.LENGTH_LONG).show();
		IntentFilter filter = new IntentFilter(
				"com.androidhuman.action.isAlive");
		filter.addAction(Intent.ACTION_SCREEN_OFF);
		registerReceiver(mReceiver, filter);
		return Aegis_Lock_Service.START_NOT_STICKY;
	}

	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}
}