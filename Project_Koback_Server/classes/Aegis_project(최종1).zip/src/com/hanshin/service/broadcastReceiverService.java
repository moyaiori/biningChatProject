package com.hanshin.service;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class broadcastReceiverService extends BroadcastReceiver {

	@Override
	public void onReceive(Context context, Intent intent) {
		
		if (intent.getAction().equals("android.intent.action.BOOT_COMPLETED")) {
			Log.i("BOOTSVC", "Intent received");

			ComponentName cn = new ComponentName(context.getPackageName(),
					Aegis_Lock_Service.class.getName());
			ComponentName svcName = context.startService(new Intent()
					.setComponent(cn));
			if (svcName == null)
				Log.e("BOOTSVC", "Could not start service " + cn.toString());
		}
		
	}
}
