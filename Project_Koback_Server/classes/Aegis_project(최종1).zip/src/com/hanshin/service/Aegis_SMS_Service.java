package com.hanshin.service;

import java.util.List;
import java.util.Locale;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningTaskInfo;
import android.app.PendingIntent;
import android.app.PendingIntent.CanceledException;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.location.Address;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.IBinder;
import android.os.SystemClock;
import android.telephony.SmsManager;
import android.telephony.SmsMessage;
import android.widget.Toast;

import com.hanshin.aegis_project.MenuActivity;
import com.hanshin.database.DBManager;
import com.hanshin.permission.PopupActivity;
import com.hanshin.sms.Aegis_SMS_Siren_Activity;

public class Aegis_SMS_Service extends Service {
	protected static final String TAG = null;
	public static String code;
	public static String sirenSet;
	public static String sirenClear;
	public static String lockSet;
	public static String lockClear;
	public static String gpsSet;
	
	private DBManager dbmgr;
	
	
	
	private String ACTION_SMS_RECEIVED = "android.provider.Telephony.SMS_RECEIVED";
	


	// gps����-------------------------------------------------

	final SmsManager sms = SmsManager.getDefault();
	double latitude = 0; // ����
	double longitude = 0; // �浵
	Geocoder geoCoder; // �������ڴ�

	String provider; // ��ġ ������
	LocationManager locationManager;
	Criteria criteria;
	Location location;
	String SendMassage = null; // �����޼��� ����

	// gps����-------------------------------------------------
	
	// �۹̼� ����
	private ActivityManager am;
	private List<RunningTaskInfo> info;
	private ComponentName topActivity;
	private String topname;
	private PendingIntent p;
	
	public BroadcastReceiver mReceiver = new BroadcastReceiver() {
		
		
		@Override
		public void onReceive(Context context, Intent intent) {
			// ��ε�ĳ��Ʈ ���ù� ����
			String message = "";
			String receiveNum = null;
		
	
			dbmgr = new DBManager(context);
			SQLiteDatabase sdb;
			sdb = dbmgr.getWritableDatabase();
			
			Cursor c = sdb.query("gps",null,null,null,null,null,null);			
			c.moveToFirst();
			gpsSet = c.getString(c.getColumnIndex("Code"));
			c.close();
			
			c = sdb.query("siren",null,null,null,null,null,null);
			c.moveToFirst();
			sirenSet = c.getString(c.getColumnIndex("Code"));
			sirenClear = c.getString(c.getColumnIndex("Clear"));
			c.close();
			
			
			c = sdb.query("lock",null,null,null,null,null,null);
			c.moveToFirst();
			lockSet = c.getString(c.getColumnIndex("Code"));
			lockClear = c.getString(c.getColumnIndex("Clear"));
			c.close();
			

			Bundle bundle = intent.getExtras();
			if (bundle != null) {
				Object[] pdus = (Object[]) bundle.get("pdus");

				for (Object pdu : pdus) {
					SmsMessage smsMessage = SmsMessage
							.createFromPdu((byte[]) pdu);
					message += smsMessage.getMessageBody();
					receiveNum = smsMessage.getOriginatingAddress();

				}
			}


			if (message.equals(gpsSet)) {
				// ---------------------------------------------------------------
				// ���������ѱ�
				WifiManager wManager_ = null;
				wManager_ = (WifiManager) getSystemService(Context.WIFI_SERVICE);
				wManager_.setWifiEnabled(true);
				// ---------------------------------------------------------------
				
				String check=null;
				ConnectivityManager cm = (ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);

				NetworkInfo ni = cm.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
				boolean isMobileConn = ni.isConnected();

				ni = cm.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
				boolean isWifiConn = ni.isConnected();
				
				
				if(isWifiConn) {
					check = " �� 100m�̳�";
				} else if(isMobileConn) {
					check = " �� 1km�̳�";
				}else{
					check = " ����Ǿ����� �ʽ��ϴ�.";
				}
				


				// ��ġ���� �޾ƿ��� �Լ�-----------------------------------------
				SendMassage = checkMyLocation();
				// ---------------------------------------------------------------
				String massage = SendMassage+check;
				// ���� ������----------------------------------------------------
				sms.sendTextMessage(receiveNum, null, massage,
						null, null);
				// ---------------------------------------------------------------
			}
			
		
			if(message.equals(sirenSet)) {
				SystemClock.sleep(1000);
				intent = new Intent(Aegis_SMS_Service.this, Aegis_SMS_Siren_Activity.class);
				intent.putExtra("sirenClear", sirenClear);
				intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);				
				context.startActivity(intent);
			}
			
			if(message.equals(lockSet)){
				Aegis_Lock_Service.key=1;
			}

		}
	};
	
	@Override
	public void onCreate() {
		super.onCreate();
		am = (ActivityManager) getSystemService(this.ACTIVITY_SERVICE);
	}
	
	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		Toast.makeText(this, "���񽺰� ���� �Ǿ����ϴ�.", Toast.LENGTH_LONG).show();
		// ���� ���� �� �������͸��ù��� �̿��� SMS���ù��� ���
	
		IntentFilter filter = new IntentFilter(ACTION_SMS_RECEIVED);
		registerReceiver(mReceiver, filter);
		
//		sirenSet = intent.getStringExtra("sirenSet");
//		sirenClear = intent.getStringExtra("sirenClear");
		
//		gpsSet = intent.getStringExtra("gpsSet");

		intent = new Intent(this,PopupActivity.class);
        p = PendingIntent.getActivity(this, 0, intent, 0);
     
		new Thread(mRun).start();
		return  Aegis_SMS_Service.START_NOT_STICKY;
	}

	Runnable mRun = new Runnable() {
		public void run() {
			try {
				while (true) {
					// ������ ���̽��� üũ ���� ��Ű�� ���� HashMap�� ��´�
					MenuActivity.CHECK = true;
					DBManager dbHelper = new DBManager(getApplicationContext());
					SQLiteDatabase db = dbHelper.getWritableDatabase();
					Cursor cursor = dbHelper.selectApp(db);
					while(cursor.moveToNext()){
						info = am.getRunningTasks(2);
						topActivity = info.get(0).topActivity;
						topname = topActivity.getPackageName();
					//	System.out.println("Go : " + cursor.getString(0) + " " + cursor.getString(1));
						if(topname.equals("com.sec.android.app.launcher")){
						} 
						else if(topname.equals(cursor.getString(0)) && cursor.getString(1).equals("1")){
							MenuActivity.PACK = cursor.getString(0);
							MenuActivity.APP = cursor.getString(2);
							while(MenuActivity.CHECK){
								info = am.getRunningTasks(2);
								topActivity = info.get(0).topActivity;
								topname = topActivity.getPackageName();
								if(topname.equals("com.sec.android.app.camera") || topname.equals("com.android.browser")
										|| topname.equals("com.android.contacts") || topname.equals("com.sec.android.gallery3d")
										 || topname.equals("com.google.android.apps.maps")){
									try {
							        	p.send();
							        } catch (CanceledException e) {
							        	e.printStackTrace();
							        }
								}
							}
						}
						Thread.sleep(10);
					}
					db.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	};
	
	@Override
	public void onDestroy() {
		/*
		if (mReceiver != null)
			unregisterReceiver(mReceiver);
		Toast.makeText(this, "���񽺰� ���� �Ǿ����ϴ�.", Toast.LENGTH_LONG).show();*/
	}

	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		return null;
	}

	public String checkMyLocation() {
		geoCoder = new Geocoder(this, Locale.KOREAN);
		String massage;// ���� �޼���
		locationManager = (LocationManager) this
				.getSystemService(Context.LOCATION_SERVICE);
		criteria = new Criteria();
		provider = LocationManager.GPS_PROVIDER;
		provider = locationManager.getBestProvider(criteria, true);

		locationManager.requestLocationUpdates(provider, 10000, 100,
				new MyLocationListener());

		if (provider == null) { // gps off�̸� network���ؼ� �޾ƿ�����..
			Toast.makeText(getBaseContext(), "no GPS Provider",
					Toast.LENGTH_SHORT).show();
			provider = LocationManager.NETWORK_PROVIDER;
			location = locationManager.getLastKnownLocation(provider);
		}

		location = locationManager.getLastKnownLocation(provider);

		if (location == null) {
			try {
				Thread.sleep(10000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			location = locationManager.getLastKnownLocation(provider);
		}

		latitude = location.getLatitude();
		longitude = location.getLongitude();

		// ------------------------------------------------------
		String Area = null;
		try {
			List<Address> addresses = geoCoder.getFromLocation(
					location.getLatitude(), location.getLongitude(), 5);
			Area = addresses.get(0).getCountryName();
			if (addresses.size() > 0) {
				Address mAddress = addresses.get(0);
				Area = null;
				StringBuffer strbuf = new StringBuffer();
				String buf;
				for (int i = 0; (buf = mAddress.getAddressLine(i)) != null; i++) {
					strbuf.append(buf + "\n");
				}
				Area = strbuf.toString();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		// ------------------------------------------------------
		massage = "���� : " + latitude + "\n�浵 : " + longitude + "\n" + "�ּ�: "
				+ Area;

		return massage;

	}

	
	private class MyLocationListener implements LocationListener {

		@Override
		public void onLocationChanged(Location location) {
			// TODO Auto-generated method stub
			Aegis_SMS_Service.this.location = location;
		}

		@Override
		public void onProviderDisabled(String provider) {
			// TODO Auto-generated method stub

		}

		@Override
		public void onProviderEnabled(String provider) {
			// TODO Auto-generated method stub

		}

		@Override
		public void onStatusChanged(String provider, int status, Bundle extras) {
			// TODO Auto-generated method stub

		}
		
	}
}
