package com.hanshin.aegis_project;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import com.hanshin.permission.Aegis_Permission_Activity;
import com.hanshin.sms.Aegis_SMS_Activity;

public class MenuActivity extends Activity implements OnClickListener {
	public static boolean CHECK = true;
	public static String PACK = "";
	public static String APP = "";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.menu);
		
		Button btn_message = (Button)findViewById(R.id.btn_message);
		btn_message.setOnClickListener(this);
		
		Button btn_permission = (Button)findViewById(R.id.btn_permission);
		btn_permission.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		switch(v.getId()) {
		case R.id.btn_message:
			startActivity(new Intent(this,Aegis_SMS_Activity.class));
			break;	
		case R.id.btn_permission:
			startActivity(new Intent(this,Aegis_Permission_Activity.class));
			break;	
		}	
	}
}
