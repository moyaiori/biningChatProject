package com.hanshin.sms;

import com.hanshin.aegis_project.R;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;


public class Aegis_SMS_Siren_Activity extends Activity implements OnClickListener {
	String strEdt;
	String sirenClear;

	AlarmManager am;
	AudioManager audio;
	SoundPool pool;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.siren);		
		
		Button btn1 = (Button)findViewById(R.id.btnOK);
		
	    btn1.setOnClickListener(this);
	    
	   long startTime = SystemClock.elapsedRealtime();
	   startTime += 3*1000; // 3�� �Ŀ� �˶��̺�Ʈ �߻�
	   Intent intent = new Intent(Aegis_SMS_Siren_Activity.this, Aegis_SMS_Siren_Activity.class);  	   	   
	   PendingIntent sender = PendingIntent.getBroadcast(this, 0, intent, 0);
	    
	    
	    audio=(AudioManager)getSystemService(Context.AUDIO_SERVICE);
	    audio.setRingerMode(AudioManager.RINGER_MODE_NORMAL); //�������� ���� ���� :��
		
		audio.setStreamVolume(AudioManager.STREAM_MUSIC, (int)(audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)*1.0), AudioManager.FLAG_PLAY_SOUND);
		am = (AlarmManager)getSystemService(Context.ALARM_SERVICE);
	    
	    am.setRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP, startTime, 3*1000, sender);
	    pool = new SoundPool(1, AudioManager.STREAM_MUSIC, 0);
		int siren = pool.load(this, R.raw.ding ,1);
		SystemClock.sleep(1000);

		pool.play(siren, 1, 1, 0, -1, 1);
		
	}

	@Override
	public void onClick(View v) {
		EditText edt = (EditText)findViewById(R.id.edtPW);
		strEdt = edt.getText().toString();
		
		Intent _intent = getIntent();
		sirenClear = _intent.getStringExtra("sirenClear");
		
		System.out.println("editText :"+strEdt);
		System.out.println("getIntent:"+sirenClear);

		if(strEdt.equals(sirenClear)) {
				pool.release();
				finish();
		} 
		else {
			new AlertDialog.Builder(this).setTitle("���").setMessage("���� ��ȣ�� ��ġ���� �ʽ��ϴ�.").setNeutralButton("Close", null).show(); 
		}

				
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if(keyCode==KeyEvent.KEYCODE_BACK){
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}
	
	

}

