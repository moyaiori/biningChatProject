package com.hanshin.sms;

import com.hanshin.aegis_project.R;
import com.hanshin.database.DBManager;
import com.hanshin.service.Aegis_SMS_Service;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class sirenSetting extends Activity implements OnClickListener{

	private DBManager dbmgr;
	Spinner spinner;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.aegis_sms_siren_set);
		
		//���ɾ�ȣ����
	    Button btn1 = (Button)findViewById(R.id.button1);
	    btn1.setOnClickListener(this);

	    
	}
	
	@Override
	public void onClick(View v) {
		EditText sirenSetText = (EditText)findViewById(R.id.editText1);
		EditText sirenClearText = (EditText)findViewById(R.id.editText2);
		String str_sirenSetText = sirenSetText.getText().toString();
		String str_sirenClearText = sirenClearText.getText().toString();
		String sirenDB="";
		String clearDB="";
		
		dbmgr = new DBManager(this);		
		SQLiteDatabase sdb;
		sdb = dbmgr.getWritableDatabase();
		
		
		try{
			
			sdb.execSQL("UPDATE siren SET Code ='"+str_sirenSetText+"', Clear = '"+str_sirenClearText+"' WHERE no = 1;");
			
		}catch(SQLException e) {
			
		}
		
		Cursor c = sdb.query("siren",null,null,null,null,null,null);
		
		c.moveToFirst();

		sirenDB = c.getString(c.getColumnIndex("Code"));	
		clearDB = c.getString(c.getColumnIndex("Clear"));
		
		Toast.makeText(this, sirenDB, Toast.LENGTH_LONG).show();
		//Toast.makeText(this, clearDB, Toast.LENGTH_LONG).show();
		c.close();
		dbmgr.close();
		
		Intent intent=new Intent(this,Aegis_SMS_Service.class);
		//intent.putExtra("sirenSet", sirenDB);
		//intent.putExtra("sirenClear", clearDB);			
		startService(intent);
		
		finish(); 


	}
		
}


