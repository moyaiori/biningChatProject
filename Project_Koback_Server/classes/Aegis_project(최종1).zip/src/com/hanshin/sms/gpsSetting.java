package com.hanshin.sms;

import com.hanshin.aegis_project.R;
import com.hanshin.database.DBManager;
import com.hanshin.service.Aegis_SMS_Service;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class gpsSetting extends Activity implements OnClickListener {

	private DBManager dbmgr;
	Spinner spinner;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.aegis_sms_gps_set);

		// ���ɾ�ȣ����
		Button btn1 = (Button) findViewById(R.id.button1);
		btn1.setOnClickListener(this);

	}

	@Override
	public void onClick(View v) {
		EditText edt = (EditText) findViewById(R.id.editText1);
		String str = edt.getText().toString();
		String gpsDB="";
		
		dbmgr = new DBManager(this);
		SQLiteDatabase sdb;
		sdb = dbmgr.getWritableDatabase();


		try {
				sdb.execSQL("UPDATE gps SET Code ='" + str + "' WHERE no = 1;");

		} catch (SQLException e) {

		}


		Cursor c = sdb.query("gps",null,null,null,null,null,null);
		
		c.moveToFirst();

		gpsDB = c.getString(c.getColumnIndex("Code"));				
		Toast.makeText(this, gpsDB, Toast.LENGTH_LONG).show();

		Intent intent = new Intent(this, Aegis_SMS_Service.class);
//		intent.putExtra("gpsSet", gpsDB);
		c.close();
		dbmgr.close();
		
		startService(intent);

		finish();


	}

}
