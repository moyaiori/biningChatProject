package com.hanshin.sms;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import com.hanshin.aegis_project.R;
import com.hanshin.lock.lockSetting;


public class Aegis_SMS_Activity extends Activity implements OnClickListener {
	public static String code;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.aegis_sms);


		Button btn1 = (Button) findViewById(R.id.gps);
		btn1.setOnClickListener(this);
		Button btn2 = (Button) findViewById(R.id.siren);
		btn2.setOnClickListener(this);
		Button btn3 = (Button) findViewById(R.id.lock);
		btn3.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {


		switch (v.getId()) {

		case R.id.gps:
			Intent intent_gps;
			intent_gps = new Intent(this, gpsSetting.class);
			startActivity(intent_gps);
			break;

		case R.id.siren:
			Intent intent;
			intent = new Intent(this, sirenSetting.class);
			startActivity(intent);
			break;
			
		case R.id.lock:
			Intent intent_lock;
			intent_lock = new Intent(this, lockSetting.class);
			startActivity(intent_lock);
			break;	
		}

	}

}
