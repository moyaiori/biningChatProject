package com.hanshin.permission;

import java.util.List;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningTaskInfo;
import android.content.ComponentName;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;

import com.hanshin.aegis_project.MenuActivity;
import com.hanshin.aegis_project.R;
import com.hanshin.database.DBManager;
import com.hanshin.sms.Aegis_SMS_Activity;

public class PopupActivity extends Activity implements OnClickListener {
	private DBManager dbHelper;
	private SQLiteDatabase db;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.popup);
		
		Button btn_ok = (Button)findViewById(R.id.btn_ok);
		btn_ok.setOnClickListener(this);
		
		Button btn_cancel = (Button)findViewById(R.id.btn_cancel);
		btn_cancel.setOnClickListener(this);

		dbHelper = new DBManager(this);
		db = dbHelper.getWritableDatabase();
		
	}
	
	@Override
	public void onClick(View v) {
		switch(v.getId()) {
		case R.id.btn_ok:
			MenuActivity.CHECK = false;
			// Database check �� 0���� ����
			dbHelper.updateCheck("0", MenuActivity.PACK, MenuActivity.APP);
			finish();
			break;	
		case R.id.btn_cancel:
			MenuActivity.CHECK = false;
			Intent intent = new Intent(Intent.ACTION_MAIN);
			intent.addCategory(Intent.CATEGORY_HOME);
			startActivity(intent);
			finish();
			break;	
		}	
	}
	
	
	@Override
	public void onBackPressed() {
	//super.onBackPressed();
	}
}
