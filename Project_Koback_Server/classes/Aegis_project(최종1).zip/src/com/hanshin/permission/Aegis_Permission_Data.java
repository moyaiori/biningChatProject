package com.hanshin.permission;

import android.graphics.drawable.Drawable;

public class Aegis_Permission_Data {
	private Drawable image;
	private String name;
	private String pack;
	private int score;
	private int check;
	
	public Aegis_Permission_Data(Drawable image,String name,String pack,int score,int check){
		this.image = image;
		this.name = name;
		this.pack = pack;
		this.score = score;
		this.check = check;
	}

	public Drawable getImage() {
		return image;
	}

	public void setImage(Drawable image) {
		this.image = image;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPack() {
		return pack;
	}

	public void setPack(String pack) {
		this.pack = pack;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public int getCheck() { 
		return check;
	}

	public void setCheck(int check) {
		this.check = check;
	}
}
