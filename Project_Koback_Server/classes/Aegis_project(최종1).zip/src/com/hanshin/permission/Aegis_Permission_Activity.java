package com.hanshin.permission;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;

import com.hanshin.aegis_project.R;
import com.hanshin.database.DBManager;

public class Aegis_Permission_Activity extends Activity implements OnItemSelectedListener {
	// Package ���� ����
	private PackageManager packageManager;
	private ArrayList<Aegis_Permission_Data> appList;
	private List<ResolveInfo> packageList;
	private Intent intent;
	// ListView ���� ����
	private ListView appListview;
	private Aegis_Permission_Adapter permissionAdapter;
	private PackageInfo info;
	// Spinner ���� ����
	private ArrayList<String> sortData;
	private ArrayAdapter<String> sortAdapter;
	//
	private DBManager dbHelper;
	private SQLiteDatabase db;
	private Cursor cursor;
	private HashMap<String,String> map;
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.aegis_permission);
        
        packageManager = this.getApplicationContext().getPackageManager();
        intent = new Intent(Intent.ACTION_MAIN, null); // ��Ű�� �Ŵ��� ȣ���� ���� Intent.ACTION_MAIN
        intent.addCategory(Intent.CATEGORY_LAUNCHER);            
        packageList = packageManager.queryIntentActivities(intent,PackageManager.PERMISSION_GRANTED);            

        
        dbHelper = new DBManager(this);
		db = dbHelper.getWritableDatabase();
		cursor = dbHelper.selectApp(db);
		map = new HashMap<String,String>();
		
        // ���� ������ Ŀ���� �̵���Ų��.
        while(cursor.moveToNext()) {
        	// �� �÷��� �˻� ����� ������ String ����
            String pack,check,name;
            // ù��° �÷��� �����͸� ���ڿ� �������� ��´�.
        	pack = cursor.getString(0);
        	// �ι�° �÷��� �����͸� ���ڿ� �������� ��´�.
        	check = cursor.getString(1);
        	name = cursor.getString(2);
            System.out.println(pack + " : " + check);
        	map.put(name+pack,check);
        }
        db.close();
        
        appList = new ArrayList<Aegis_Permission_Data>();

        for (ResolveInfo in : packageList) {        
        	String appPackageName   = in.activityInfo.packageName;
        	String appName          = in.loadLabel(packageManager).toString();
        	Drawable drawable       = in.activityInfo.loadIcon(packageManager);
        	
            int value = 0;
    		try {
    			info = packageManager.getPackageInfo(appPackageName, packageManager.GET_PERMISSIONS);
    		} catch (NameNotFoundException e) {
    			e.printStackTrace();
    		}
            
            String[] strPermission = info.requestedPermissions;
            
            if(strPermission != null){
            	for(String str : strPermission){
            		if(str.equals("android.permission.INTERNET")){
            			value = value + 2;
            		}else if(str.equals("android.permission.CALL_PHONE")){
            			value = value + 2;
            		}else if(str.equals("android.permission.SEND_SMS")){
            			value = value + 2;
            		}else if(str.equals("android.permission.ACCESS_MOCK_LOCATION")){
            			value = value + 2;
            		}else if(str.equals("android.permission.CAMERA")){
            			value = value + 2;
            		}
            	}
            }
            int ch = Integer.parseInt(map.get(appName+appPackageName));
        	appList.add(new Aegis_Permission_Data(drawable, appName,appPackageName,value,ch));
   //     	System.out.println(appName + " : " + appPackageName + " : " + ch);
        }

        permissionAdapter = new Aegis_Permission_Adapter(this, appList);
        appListview = (ListView) findViewById(R.id.list_appInfo);
        appListview.setAdapter(permissionAdapter);
        
        sortData = new ArrayList<String>();
        sortData.add("�����ټ�");
        sortData.add("���赵��");
        sortData.add("���ٰ���:���ͳ�");
        sortData.add("���ٰ���:��ȭ");
        sortData.add("���ٰ���:�޼���");
        sortData.add("���ٰ���:GPS");
        sortData.add("���ٰ���:ī�޶�");
        sortAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item, sortData);
		// ���ǳ� �Ӽ�
		Spinner sp = (Spinner) this.findViewById(R.id.spi_appSort);
		sp.setAdapter(sortAdapter);
		sp.setOnItemSelectedListener(this);
    }
	
	@Override
	public void onItemSelected(AdapterView<?> arg0, View arg1, int position,long arg3) {
		ArrayList<Aegis_Permission_Data> appTemp = new ArrayList<Aegis_Permission_Data>();
		Aegis_Permission_Data temp;
        
		switch(position){
		case 0:
			for(int i=0;i<appList.size();i++){
				appTemp.add(appList.get(i));
			}
			for(int i=0;i<appTemp.size()-1;i++){
	            for(int j=0; j< appTemp.size()-1-i;j++){
	                if(appTemp.get(j).getName().compareTo(appTemp.get(j+1).getName()) > 0){                   
	                    temp = appTemp.get(j);
	                    appTemp.set(j, appTemp.get(j+1));
	                    appTemp.set(j+1, temp);
	                }              
	            }          
	        }    
			permissionAdapter = new Aegis_Permission_Adapter(this, appTemp);
			permissionAdapter.notifyDataSetChanged();
			appListview.setAdapter(permissionAdapter);
			break;
		case 1:
			for(int i=0;i<appList.size();i++){
				appTemp.add(appList.get(i));
			}
			for(int i=0;i<appTemp.size()-1;i++){
	            for(int j=0; j< appTemp.size()-1-i;j++){
	                if(appTemp.get(j).getScore() < appTemp.get(j+1).getScore()){                   
	                    temp = appTemp.get(j);
	                    appTemp.set(j, appTemp.get(j+1));
	                    appTemp.set(j+1, temp);
	                }              
	            }          
	        }  
			for(int i=0;i<appList.size();i++){
				System.out.println(appList.get(i).getName());
			}
			permissionAdapter = new Aegis_Permission_Adapter(this, appTemp);
			permissionAdapter.notifyDataSetChanged();
			appListview.setAdapter(permissionAdapter);
			break;
		case 2:
			permissionSort("android.permission.INTERNET");
			break;
		case 3:
			permissionSort("android.permission.CALL_PHONE");
			break;
		case 4:
			permissionSort("android.permission.SEND_SMS");
			break;
		case 5:
			permissionSort("android.permission.ACCESS_MOCK_LOCATION");
			break;
		case 6:
			permissionSort("android.permission.CAMERA");
			break;
		}
	}

	@Override
	public void onNothingSelected(AdapterView<?> arg0) {
	}
	
	public void permissionSort(String permission){
		ArrayList<Aegis_Permission_Data> appTemp = new ArrayList<Aegis_Permission_Data>();
		for (int i = 0; i < appList.size(); i++) {
			try {
				info = packageManager.getPackageInfo(appList.get(i)
						.getPack(), packageManager.GET_PERMISSIONS);
			} catch (NameNotFoundException e) {
				e.printStackTrace();
			}

			String[] strPermission = info.requestedPermissions;
			if (strPermission != null) {
				for (String str : strPermission) {
					if(str.equals(permission)){
						appTemp.add(appList.get(i));
					}
				}
			}
		}
		permissionAdapter = new Aegis_Permission_Adapter(this, appTemp);
		permissionAdapter.notifyDataSetChanged();
		appListview.setAdapter(permissionAdapter);
	}
}
