package com.hanshin.permission;

import java.util.ArrayList;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.hanshin.aegis_project.R;
import com.hanshin.database.DBManager;

public class Aegis_Permission_Adapter extends BaseAdapter {
	private Context context; // �Ѿ�� Activity ������ ���� ����
	private LayoutInflater inflater;
	private ArrayList<Aegis_Permission_Data> arrData;

	public Aegis_Permission_Adapter(Context c, ArrayList<Aegis_Permission_Data> arr) {
		this.arrData = arr;
		this.context = c;
		inflater = (LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	}

	public View getView(final int position, View convertView, ViewGroup parent) {
		if (convertView == null) {
			convertView = inflater.inflate(R.layout.permission_listitem, parent, false);
		}
		
		ImageView image = (ImageView) convertView.findViewById(R.id.img_appIcon);
		image.setImageDrawable(arrData.get(position).getImage());

		TextView name = (TextView) convertView.findViewById(R.id.txt_appName);
		name.setText(arrData.get(position).getName());

		TextView score = (TextView) convertView.findViewById(R.id.txt_Score);
		

		final ToggleButton check = (ToggleButton) convertView.findViewById(R.id.toggle_permission);
		System.out.println("pack : " + arrData.get(position).getPack() + " // check : " + arrData.get(position).getCheck());
		if(arrData.get(position).getCheck() == 1){
			check.setChecked(true);
		}
		else{
			check.setChecked(false);
		}
		check.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				DBManager dbHelper = new DBManager(context);
				if (check.isChecked()) {
					System.out.println("Data : " + arrData.get(position).getPack() + " : " + arrData.get(position).getCheck());
					arrData.get(position).setCheck(1);
					dbHelper.updateCheck("1", arrData.get(position).getPack(),arrData.get(position).getName());
				} else {
					arrData.get(position).setCheck(0);
					dbHelper.updateCheck("0", arrData.get(position).getPack(),arrData.get(position).getName());
				}
			}
		});
		ImageView imgWifi = (ImageView) convertView.findViewById(R.id.img_wifiIcon);
		ImageView imgPhone = (ImageView) convertView.findViewById(R.id.img_phoneIcon);
		ImageView imgSMS = (ImageView) convertView.findViewById(R.id.img_smsIcon);
		ImageView imgGPS = (ImageView) convertView.findViewById(R.id.img_gpsIcon);
		ImageView imgCamera = (ImageView) convertView.findViewById(R.id.img_cameraIcon);
		imgWifi.setVisibility(View.INVISIBLE);
		imgPhone.setVisibility(View.INVISIBLE);
		imgSMS.setVisibility(View.INVISIBLE);
		imgGPS.setVisibility(View.INVISIBLE);
		imgCamera.setVisibility(View.INVISIBLE);
		
		PackageInfo info = null;
        int value = 0;
		try {
			info = context.getPackageManager().getPackageInfo(arrData.get(position).getPack(), context.getPackageManager().GET_PERMISSIONS);
		} catch (NameNotFoundException e) {
			e.printStackTrace();
		}
        
        String[] strPermission = info.requestedPermissions;
        
        if(strPermission != null){
        	for(String str : strPermission){
        		if(str.equals("android.permission.INTERNET")){
        			value = value + 2;
        			imgWifi.setVisibility(View.VISIBLE);
        		}else if(str.equals("android.permission.CALL_PHONE")){
        			value = value + 2;
        			imgPhone.setVisibility(View.VISIBLE);
        		}else if(str.equals("android.permission.SEND_SMS")){
        			value = value + 2;
        			imgSMS.setVisibility(View.VISIBLE);
        		}else if(str.equals("android.permission.ACCESS_MOCK_LOCATION")){
        			value = value + 2;
        			imgGPS.setVisibility(View.VISIBLE);
        		}else if(str.equals("android.permission.CAMERA")){
        			value = value + 2;
        			imgCamera.setVisibility(View.VISIBLE);
        		}
        	}
        }
        arrData.get(position).setScore(value);
        score.setText(String.valueOf(arrData.get(position).getScore()));
		return convertView;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return arrData.size();
	}

	@Override
	public Object getItem(int arg0) {
		return arrData.get(arg0).getName();
	}

	@Override
	public long getItemId(int arg0) {
		return arg0;
	}
}
