package com.hanshin.database;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class DBManager extends SQLiteOpenHelper{
	public DBManager(Context context) {
		super(context, "AegisDB", null, 1);
	}
	
	@Override
	public void onCreate(SQLiteDatabase db) {
		db.execSQL("CREATE TABLE gps (no INTEGER, Code TEXT);");
		db.execSQL("INSERT INTO gps VALUES(1,'0000');");
		
		db.execSQL("CREATE TABLE siren (no INTEGER, Code TEXT, Clear TEXT);");
		db.execSQL("INSERT INTO siren VALUES(1,'0000','0000');");
		
		db.execSQL("CREATE TABLE lock (no INTEGER, Code TEXT, Clear TEXT);");
		db.execSQL("INSERT INTO lock VALUES(1,'0000','0000');");
		
		db.execSQL("create table lockscreen (no INTEGER, Code text);");
		db.execSQL("CREATE TABLE Apps(num INTEGER PRIMARY KEY AUTOINCREMENT," +
				"appName TEXT," +
    			"appPack TEXT," +
    			"appCheck TEXT);");
		
	}
	
	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){}
	
	public void insertApp(String name,String pack,String check){
    	SQLiteDatabase db  = getWritableDatabase();
        String str = "insert into Apps(appName, appPack ,appCheck) values('" + name + "','" + pack + "' ,'" + check + "');";
        // ������ �����Ѵ�.
        db.execSQL(str);
        // �����ͺ��̽���  �ݴ´�.
        db.close();
    }
     
    public Cursor selectApp(SQLiteDatabase db){
        // �����͸� �˻����ִ� ������ �����Ͽ� rawQuery �޼ҵ带 ȣ���Ѵ�.
        Cursor cursor = db.rawQuery("select appPack,appCheck,appName from Apps;", null);
        return cursor;
    }
    
    public void updateCheck(String check, String pack, String name){
    	SQLiteDatabase db  = getWritableDatabase();
    	String str = "update Apps set appCheck = '" + check + "' where appName = '" + name + "' and appPack = '" + pack + "'";
    	db.execSQL(str);
        // �����ͺ��̽���  �ݴ´�.
        db.close();
    }
    
    
    
    

}
