package com.hanshin.lock;


import com.hanshin.aegis_project.R;
import com.hanshin.database.DBManager;

import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.InputType;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LockActivity extends Activity{

	private String password;
	private EditText pw1;
	private EditText pw2;
	private EditText pw3;
	private EditText pw4;
	private DBManager dbmgr;
	private String clearLock;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);	// Ÿ��Ʋ ��(Title bar)�� ���ֱ�
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED);  //lock ȭ�� ���� ���̱�
			//| WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD   // Keyguard�� ���ش�.(�ϴ� �̰� �̻���) 
		   // | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON  //Activity�� �ױ� ������ ȭ���� ���� ���·� ���� 
		   // | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON); //ȭ���� �Ҵ�

		setContentView(R.layout.lock);

		pw1 = (EditText)findViewById(R.id.et_pw1);
		pw1.setInputType(InputType.TYPE_CLASS_NUMBER);
		pw2 = (EditText)findViewById(R.id.et_pw2);
		pw2.setInputType(InputType.TYPE_CLASS_NUMBER);
		pw3 = (EditText)findViewById(R.id.et_pw3);
		pw3.setInputType(InputType.TYPE_CLASS_NUMBER);
		pw4 = (EditText)findViewById(R.id.et_pw4);
		pw4.setInputType(InputType.TYPE_CLASS_NUMBER);

		dbmgr = new DBManager(this);		
		SQLiteDatabase sdb;
		sdb = dbmgr.getWritableDatabase();
				
		Cursor c = sdb.query("lock",null,null,null,null,null,null);

		c.moveToFirst();
		
		clearLock = c.getString(c.getColumnIndex("Clear"));
		
		c.close();
		dbmgr.close();
		
		Button b = (Button)findViewById(R.id.bt_back);
		b.setOnClickListener(new OnClickListener(){
			public void onClick(View v){
				password = String.valueOf(pw1.getText())+String.valueOf(pw2.getText())+String.valueOf(pw3.getText())+String.valueOf(pw4.getText());

				if(password.equals(clearLock)){
					finish();
				}else{
					Toast.makeText(LockActivity.this, "��й�ȣ�� ��ġ���� �ʽ��ϴ�.", Toast.LENGTH_SHORT).show();
				}
			}			
		});

	}

	public boolean onKeyDown( int KeyCode, KeyEvent event )
	{
		if( event.getAction() == KeyEvent.ACTION_DOWN ){
			if( KeyCode == KeyEvent.KEYCODE_BACK ){
				return true;
			}
		}
	return super.onKeyDown( KeyCode, event );
	}

}