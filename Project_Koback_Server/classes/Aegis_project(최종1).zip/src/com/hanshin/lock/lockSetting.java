package com.hanshin.lock;

import java.util.List;

import com.hanshin.aegis_project.R;
import com.hanshin.database.DBManager;
import com.hanshin.service.Aegis_Lock_Service;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.ActivityManager.RunningTaskInfo;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class lockSetting extends Activity implements OnClickListener {

	private AlertDialog mDialog = null;
	private AlertDialog mDialog2 = null;
	private String name = null;
	private DBManager dbmgr;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.aegis_sms_lockscreen_set);

		Button btn1 = (Button) findViewById(R.id.bt_lockpw);
		btn1.setOnClickListener(this);

		Button btn2 = (Button) findViewById(R.id.bt_homesetting);
		btn2.setOnClickListener(this);
		
		Button btn3 = (Button) findViewById(R.id.bt_exit);
		btn3.setOnClickListener(this);

		ComponentName topActivity = null;
		ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
		List<RunningTaskInfo> Info = am.getRunningTasks(10);
		for (int i = 0; i < Info.size(); i++) {
			topActivity = Info.get(0).topActivity;
		}
		name = topActivity.getPackageName();
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.bt_lockpw:

			EditText edt = (EditText) findViewById(R.id.et_lock);
			EditText edt2 = (EditText) findViewById(R.id.et_lockpw);
			String str = edt.getText().toString();
			String str2 = edt2.getText().toString();

			
			
			dbmgr = new DBManager(this);		
			SQLiteDatabase sdb;
			sdb = dbmgr.getWritableDatabase();
			
			
			try{				
				sdb.execSQL("UPDATE lock SET Code ='"+str+"', Clear = '"+str2+"' WHERE no = 1;");
			}catch(SQLException e) {
				
			}			
			Cursor c = sdb.query("lock",null,null,null,null,null,null);

			c.moveToFirst();

			String lockDB = c.getString(c.getColumnIndex("Code"));	
			String clearDB = c.getString(c.getColumnIndex("Clear"));
			
			
			edt.setText(lockDB);
			edt2.setText(clearDB);
			c.close();
			dbmgr.close();
			Toast.makeText(this, "��� ���� ���� �� ������ȣ�� ���� �Ǿ����ϴ�.", Toast.LENGTH_SHORT).show();
			finish();
			break;
			
		case R.id.bt_homesetting:
			/*
			PackageManager pPackMgr = getPackageManager();
			String szPackName = name; // ���� ������ Package�� Get
			pPackMgr.clearPackagePreferredActivities(szPackName);
			mDialog = createDialog();
			mDialog.show();
			*/
			break;
		case R.id.bt_exit:
			Aegis_Lock_Service.key=0;
			finish();
			Toast.makeText(this, "��� ���񽺰� ���� �Ǿ����ϴ�.", Toast.LENGTH_SHORT).show();
			break;
		}
	}

	private AlertDialog createDialog() {
		AlertDialog.Builder ab = new AlertDialog.Builder(this);
		ab.setTitle("Ȩ��ư �⺻����");
		ab.setMessage("\"Aegislock\" ���ø����̼��� �����ϰ� \"�⺻������ ���� �Ǵ� �׻�\"�� �����ϼ���.");
		// ab.setCancelable(false);
		ab.setIcon(getResources().getDrawable(R.drawable.ic_launcher));

		ab.setPositiveButton("Ȯ��", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface arg0, int arg1) {
				Intent intent = new Intent();
				intent.setAction("android.intent.action.MAIN");
				intent.addCategory("android.intent.category.HOME");
				intent.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS
						| Intent.FLAG_ACTIVITY_FORWARD_RESULT
						| Intent.FLAG_ACTIVITY_NEW_TASK
						| Intent.FLAG_ACTIVITY_PREVIOUS_IS_TOP
						| Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
				startActivity(intent);
			}
		});

		ab.setNegativeButton("���", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface arg0, int arg1) {
				if (mDialog != null && mDialog.isShowing())
					mDialog.dismiss();
			}
		});

		return ab.create();
	}
}
