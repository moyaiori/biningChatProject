/** Automatically generated file. DO NOT MODIFY */
package com.example.guidefair;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}