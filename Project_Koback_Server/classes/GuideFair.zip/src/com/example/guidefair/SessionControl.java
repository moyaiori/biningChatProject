package com.example.guidefair;

import java.util.List;

import org.apache.http.client.HttpClient;
import org.apache.http.cookie.Cookie;
import org.apache.http.impl.client.DefaultHttpClient;

public class SessionControl {

	static DefaultHttpClient httpClient = null;
	static List<Cookie> cookies;

	public static HttpClient getHttpClient() {
		if (httpClient == null) {
			SessionControl.setHttpClient(new DefaultHttpClient());

		}
		return httpClient;
	}

	public static void setHttpClient(DefaultHttpClient httpClient) {
		SessionControl.httpClient = httpClient;

	}

}
