package com.example.guidefair;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {

	public static Activity mActivity;

	private WebView mWebView;
	private String ip = "192.168.0.26";
	private String port = "8088";
	private String url = "http://" + ip + ":" + port + "/GuideFair/App/";

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		mWebView = (WebView) findViewById(R.id.webView);
	}

	// 웹뷰
	public void onClick(View v) {
		String web = url;

		switch (v.getId()) {
		case R.id.siteplan_btn:
			web += "siteplan.jsp";
			break;
		case R.id.timetable_btn:
			Intent in = new Intent(MainActivity.this, TimetableActivity.class);
			startActivity(in);
			break;
		case R.id.event_btn:
			web += "event_list.jsp";
			break;
		default:
			break;
		}
		mWebView.getSettings().setJavaScriptEnabled(true);
		mWebView.loadUrl(web);
		mWebView.setWebViewClient(new WebViewClientClass());
	}

	private class WebViewClientClass extends WebViewClient {
		public boolean shouldOverrideUrlLoading(WebView view, String url) {
			view.loadUrl(url);
			return true;
		}
	}

	// Action bar
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.action_bar, menu);

		return true;
	}

	public boolean onOptionsItemSelected(MenuItem item) {
		String web = url;

		switch (item.getItemId()) {
		case R.id.my_reserve:
			//web += "my_reserve.jsp";
			Intent in = new Intent(MainActivity.this, ReserveListActivity.class);
			startActivity(in);
			break;
		case R.id.my_event:
			web += "my_event_list.jsp";
			break;
		case R.id.pamphlet:
			web += "pamphlet.jsp";
			break;
		case R.id.message:
			web += "pamphlet.jsp";
			break;
		case R.id.my_info:
			web += "my_info.jsp";
			break;
		case R.id.logout:
			finish();
		default:
			return true;
		}
		mWebView.getSettings().setJavaScriptEnabled(true);
		mWebView.loadUrl(web);
		mWebView.setWebViewClient(new WebViewClientClass());

		return super.onOptionsItemSelected(item);
	}
}
