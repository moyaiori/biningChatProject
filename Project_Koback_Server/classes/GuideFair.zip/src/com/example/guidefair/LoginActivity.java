package com.example.guidefair;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends Activity {

	private String ip = "192.168.0.26";
	private String port = "8088";
	private String url = "http://" + ip + ":" + port
			+ "/GuideFair/App/controller_Login.jsp";

	EditText telText;
	EditText pwText;

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login);

		telText = (EditText) findViewById(R.id.L_telText);
		pwText = (EditText) findViewById(R.id.L_pwText);

		// 로그인 버튼 이벤트
		Button login_btn = (Button) findViewById(R.id.L_login_btn);
		login_btn.setOnClickListener(new OnClickListener() {
			public void onClick(View arg0) {
				LoginAsyncTask sendpostreq = new LoginAsyncTask();
				sendpostreq.execute(telText.getText().toString(), pwText
						.getText().toString());
				

			}
		});

		// 박람회 참가 등록 버튼 이벤트
		Button enrol_btn = (Button) findViewById(R.id.L_enrol_btn);
		enrol_btn.setOnClickListener(new OnClickListener() {
			public void onClick(View arg0) {
				Intent in = new Intent(LoginActivity.this, EnrolActivity.class);
				startActivity(in);
			}
		});
	}

	// 웹서버 통신(Post 방식)
	private class LoginAsyncTask extends AsyncTask<String, String, String> {
		String req_code = "";

		protected String doInBackground(String... params) {
			String tel = params[0];
			String pw = params[1];

			Log.d("login", "전화번호 : " + tel + "\t비밀번호 : " + pw);

			HttpClient httpClient = SessionControl.getHttpClient();

			// HttpClient httpClient = new DefaultHttpClient();

			// 객체 연결 설정 부분
			// HttpClient httpClient = SessionControl.getHttpClient();

			// 서버 접속
			HttpPost httpPost = new HttpPost(url);

			// post방식 (key,value)
			BasicNameValuePair p_tel = new BasicNameValuePair("p_tel", tel);
			BasicNameValuePair p_pw = new BasicNameValuePair("p_pw", pw);

			List<NameValuePair> nameValuePairList = new ArrayList<NameValuePair>();
			nameValuePairList.add(p_tel);
			nameValuePairList.add(p_pw);

			StringBuilder stringBuilder = new StringBuilder();

			// 서버로 데이터를 요청(Post방식)
			try {
				UrlEncodedFormEntity urlEncodedFormEntity = new UrlEncodedFormEntity(
						nameValuePairList, "UTF-8");
				httpPost.setEntity(urlEncodedFormEntity);

				//
				HttpResponse httpResponse = httpClient.execute(httpPost);
				HttpEntity entity = httpResponse.getEntity();
				InputStream inputStream = entity.getContent();
				InputStreamReader inputStreamReader = new InputStreamReader(
						inputStream);
				BufferedReader bufferedReader = new BufferedReader(
						inputStreamReader);

				String line = null;

				while ((line = bufferedReader.readLine()) != null) {
					stringBuilder.append(line);
				}

				Log.d("login", "서버에서 받은 메세지 : " + stringBuilder.toString());

			} catch (Exception e) {
				Log.d("login", "Exception : " + e.getMessage());
				e.printStackTrace();
			}

			// 서버로부터 요청받은 데이터를 JSON을 이용하여 데이터를 추출
			try {
				JSONObject jObject = new JSONObject(stringBuilder.toString());

				req_code = jObject.getString("login_code");
				// Log.d("login", "로그인 코드 : " + req_code);

			} catch (JSONException e) {
				Log.d("login", "Exception : " + e.getMessage());
				e.printStackTrace();
			}
			return stringBuilder.toString();
		}

		protected void onPostExecute(String result) {
			super.onPostExecute(result);

			if (req_code.equals("enrol")) {
				Toast.makeText(getApplication(), "박람회 참가 미등록 전화번호 입니다.",
						Toast.LENGTH_SHORT).show();
			} else if (req_code.equals("password")) {
				Toast.makeText(getApplication(), "비밀번호가 일치하지 않습니다.",
						Toast.LENGTH_SHORT).show();
			} else if (req_code.equals("login")) {
				Toast.makeText(getApplication(), "로그인 완료", Toast.LENGTH_SHORT)
						.show();

				Intent in = new Intent(LoginActivity.this, MainActivity.class);
				startActivity(in);
			}
		}
	}
}
