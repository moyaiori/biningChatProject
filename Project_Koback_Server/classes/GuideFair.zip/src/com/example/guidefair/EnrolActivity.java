package com.example.guidefair;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class EnrolActivity extends Activity {

	private String ip = "192.168.0.26";
	private String port = "8088";
	private String url = "http://" + ip + ":" + port
			+ "/GuideFair/App/controller_Enrol.jsp";

	EditText telText;
	EditText pwText;
	EditText nameText;
	EditText dobText;
	EditText genderText;
	EditText jobText;
	EditText educationText;
	EditText majorText;
	EditText emailText;
	EditText resumeText;

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.enrol);

		telText = (EditText) findViewById(R.id.E_telText);
		pwText = (EditText) findViewById(R.id.E_pwText);
		nameText = (EditText) findViewById(R.id.E_nameText);
		dobText = (EditText) findViewById(R.id.E_dobText);
		genderText = (EditText) findViewById(R.id.E_genderText);
		jobText = (EditText) findViewById(R.id.E_jobText);
		educationText = (EditText) findViewById(R.id.E_educationText);
		majorText = (EditText) findViewById(R.id.E_majorText);
		emailText = (EditText) findViewById(R.id.E_emailText);
		resumeText = (EditText) findViewById(R.id.E_resumeText);

		// 박람회 참가 등록 버튼 이벤트
		Button login_btn = (Button) findViewById(R.id.E_enrol_btn);
		login_btn.setOnClickListener(new OnClickListener() {
			public void onClick(View arg0) {

				EnrolAsyncTask sendpostreq = new EnrolAsyncTask();
				sendpostreq.execute(telText.getText().toString(), pwText
						.getText().toString(), nameText.getText().toString(),
						dobText.getText().toString(), genderText.getText()
								.toString(), jobText.getText().toString(),
						educationText.getText().toString(), majorText.getText()
								.toString(), emailText.getText().toString(),
						resumeText.getText().toString());
			}
		});

		// 박람회 참가 등록 취소 버튼 이벤트
		Button enrol_btn = (Button) findViewById(R.id.E_cancel_btn);
		enrol_btn.setOnClickListener(new OnClickListener() {
			public void onClick(View arg0) {
				finish();
			}
		});
	}

	// 웹서버 통신(Post 방식)
	private class EnrolAsyncTask extends AsyncTask<String, String, String> {
		String req_code = "";

		protected String doInBackground(String... params) {
			String tel = params[0];
			String pw = params[1];
			String name = params[2];
			String dob = params[3];
			String gender = params[4];
			String job = params[5];
			String education = params[6];
			String major = params[7];
			String email = params[8];
			String resume = params[9];

			Log.d("login", "전화번호 : " + tel + "\t비밀번호 : " + pw);

			HttpClient httpClient = new DefaultHttpClient();

			// 객체 연결 설정 부분
			// HttpClient httpClient = SessionControl.getHttpClient();
			// 서버 접속
			HttpPost httpPost = new HttpPost(url);

			// post방식 (key,value)
			BasicNameValuePair p_tel = new BasicNameValuePair("p_tel", tel);
			BasicNameValuePair p_pw = new BasicNameValuePair("p_pw", pw);
			BasicNameValuePair p_name = new BasicNameValuePair("p_name", name);
			BasicNameValuePair p_dob = new BasicNameValuePair("p_dob", dob);
			BasicNameValuePair p_gender = new BasicNameValuePair("p_gender",
					gender);
			BasicNameValuePair p_job = new BasicNameValuePair("p_job", job);
			BasicNameValuePair p_education = new BasicNameValuePair(
					"p_education", education);
			BasicNameValuePair p_major = new BasicNameValuePair("p_major",
					major);
			BasicNameValuePair p_email = new BasicNameValuePair("p_email",
					email);
			BasicNameValuePair p_resume = new BasicNameValuePair("p_resume",
					resume);

			List<NameValuePair> nameValuePairList = new ArrayList<NameValuePair>();
			nameValuePairList.add(p_tel);
			nameValuePairList.add(p_pw);
			nameValuePairList.add(p_name);
			nameValuePairList.add(p_dob);
			nameValuePairList.add(p_gender);
			nameValuePairList.add(p_job);
			nameValuePairList.add(p_education);
			nameValuePairList.add(p_major);
			nameValuePairList.add(p_email);
			nameValuePairList.add(p_resume);

			StringBuilder stringBuilder = new StringBuilder();

			// 서버로 데이터를 요청(Post방식)
			try {
				UrlEncodedFormEntity urlEncodedFormEntity = new UrlEncodedFormEntity(
						nameValuePairList, "UTF-8");
				httpPost.setEntity(urlEncodedFormEntity);

				//
				HttpResponse httpResponse = httpClient.execute(httpPost);
				HttpEntity entity = httpResponse.getEntity();
				InputStream inputStream = entity.getContent();
				InputStreamReader inputStreamReader = new InputStreamReader(
						inputStream);
				BufferedReader bufferedReader = new BufferedReader(
						inputStreamReader);

				String line = null;

				while ((line = bufferedReader.readLine()) != null) {
					stringBuilder.append(line);
				}

				Log.d("enrol", "서버에서 받은 메세지 : " + stringBuilder.toString());

			} catch (Exception e) {
				Log.d("enrol", "Exception : " + e.getMessage());
				e.printStackTrace();
			}

			// 서버로부터 요청받은 데이터를 JSON을 이용하여 데이터를 추출
			try {
				JSONObject jObject = new JSONObject(stringBuilder.toString());

				req_code = jObject.getString("enrol_code");
				Log.d("enrol", "enrol code : " + req_code);

			} catch (JSONException e) {
				Log.d("enrol", "Exception : " + e.getMessage());
				e.printStackTrace();
			}
			return stringBuilder.toString();
		}

		protected void onPostExecute(String result) {
			super.onPostExecute(result);

			if (req_code.equals("enrol")) {
				Toast.makeText(getApplication(), "박람회 참가 기등록 전화번호 입니다.",
						Toast.LENGTH_SHORT).show();
			} else if (req_code.equals("seccess")) {
				Toast.makeText(getApplication(), "박람회 참가등록 완료",
						Toast.LENGTH_SHORT).show();
			} else {
				Toast.makeText(getApplication(), "박람회 참가등록 실패",
						Toast.LENGTH_SHORT).show();
			}
		}
	}

}
