package com.example.guidefair;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

public class ReserveListActivity extends Activity {

	private String ip = "192.168.0.26";
	private String port = "8088";
	private String url = "http://" + ip + ":" + port
			+ "/GuideFair/App/controller_ReserveList.jsp";

	private ReserveListAdapter adapter;
	ListView rListView;

	JSONObject jObject;
	JSONArray jArray;

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.reserve_list);

		rListView = (ListView) findViewById(R.id.reserveListView);
		// rListView.setOnItemLongClickListener(itemLongClickListener);
		// rListView.setOnItemClickListener(itemClickListener);
		adapter = new ReserveListAdapter(getBaseContext(),
				R.layout.reserve_list_row);

		// 박람회 참가 등록 버튼 이벤트
		Button sequence_btn = (Button) findViewById(R.id.sequence_btn);
		sequence_btn.setOnClickListener(new OnClickListener() {
			public void onClick(View arg0) {
				ReserveListAsyncTask sendpostreq = new ReserveListAsyncTask();
				sendpostreq.execute("01090340302");

			}
		});

		// 박람회 참가 등록 취소 버튼 이벤트
		Button time_btn = (Button) findViewById(R.id.time_btn);
		time_btn.setOnClickListener(new OnClickListener() {
			public void onClick(View arg0) {

			}
		});
		
		rListView.setOnItemLongClickListener(CancelReserveListener);
	}

	// 웹서버 통신(Post 방식)
	private class ReserveListAsyncTask extends
			AsyncTask<String, String, String> {

		protected String doInBackground(String... params) {
			String tel = params[0];

			Log.d("ReserveList", "전화번호 : " + tel);

			HttpClient httpClient = SessionControl.getHttpClient();

			// 서버 접속
			HttpPost httpPost = new HttpPost(url);

			// post방식 (key,value)
			BasicNameValuePair p_tel = new BasicNameValuePair("p_tel", tel);

			List<NameValuePair> nameValuePairList = new ArrayList<NameValuePair>();
			nameValuePairList.add(p_tel);

			StringBuilder stringBuilder = new StringBuilder();

			// 서버로 데이터를 요청(Post방식)
			try {
				UrlEncodedFormEntity urlEncodedFormEntity = new UrlEncodedFormEntity(
						nameValuePairList, "UTF-8");
				httpPost.setEntity(urlEncodedFormEntity);

				//
				HttpResponse httpResponse = httpClient.execute(httpPost);
				HttpEntity entity = httpResponse.getEntity();
				InputStream inputStream = entity.getContent();
				InputStreamReader inputStreamReader = new InputStreamReader(
						inputStream);
				BufferedReader bufferedReader = new BufferedReader(
						inputStreamReader);

				String line = null;

				while ((line = bufferedReader.readLine()) != null) {
					stringBuilder.append(line);
				}

				Log.d("ReserveList",
						"서버에서 받은 메세지 : " + stringBuilder.toString());

			} catch (Exception e) {
				Log.d("ReserveList", "Exception : " + e.getMessage());
				e.printStackTrace();
			}

			return stringBuilder.toString();
		}

		//
		protected void onPostExecute(String result) {
			super.onPostExecute(result);

			// 서버로부터 요청받은 데이터를 JSON을 이용하여 데이터를 추출

			try {

				jObject = new JSONObject(result);
				jArray = jObject.getJSONArray("ReserveList");

				rListView.setAdapter(adapter);

			} catch (JSONException e) {
				Log.d("ReserveList", "Exception : " + e.getMessage());
				e.printStackTrace();
			}

		}
	}

	// 예약 리스트 어댑터
	public class ReserveListAdapter extends BaseAdapter {
		Context my_context;
		private int mRowLayout;

		public ReserveListAdapter(Context context, int layout) {
			my_context = context;
			mRowLayout = layout;
		}

		public Object getItem(int position) {
			return null;
		}

		public long getItemId(int position) {
			return position;
		}

		public int getCount() {
			return jArray.length();
		}

		public View getView(int position, View convertView, ViewGroup parent) {
			ReserveListViewHolder viewHolder;
			
			if (convertView == null) {
				LayoutInflater inflater = (LayoutInflater) my_context
						.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				convertView = inflater.inflate(mRowLayout, parent, false);

				viewHolder = new ReserveListViewHolder();

				viewHolder.bNoView = (TextView) convertView
						.findViewById(R.id.bNo_textView);
				viewHolder.bNameView = (TextView) convertView
						.findViewById(R.id.bName_textView);
				viewHolder.cNameView = (TextView) convertView
						.findViewById(R.id.cName_textView);
				viewHolder.rTimeView = (TextView) convertView
						.findViewById(R.id.rTime_textView);
				viewHolder.watingNoView = (TextView) convertView
						.findViewById(R.id.watingNo_textView);
				viewHolder.resumeCheckView = (TextView) convertView
						.findViewById(R.id.resumeCheck_textView);

				convertView.setTag(viewHolder);
			} else {
				viewHolder = (ReserveListViewHolder) convertView.getTag();
			}

			try {
				JSONObject jo = jArray.getJSONObject(position);

				viewHolder.bNoView.setText(jo.getString("bNo"));
				viewHolder.bNameView.setText(jo.getString("bName"));
				viewHolder.cNameView.setText(jo.getString("cName"));
				viewHolder.rTimeView.setText(jo.getString("rTime"));
				viewHolder.watingNoView.setText(jo.getString("watingNo"));
				viewHolder.resumeCheckView.setText(jo.getString("resumeCheck"));

			} catch (JSONException e) {
				Log.d("ReserveList", "Exception : " + e.getMessage());
				e.printStackTrace();
			}

			return convertView;
		}

		private class ReserveListViewHolder {
			// 부스 번호, 기업명, 부스명, 예약 일시, 대기순서번호, 이력서 여부,

			TextView bNoView;
			TextView bNameView;
			TextView cNameView;
			TextView rTimeView;
			TextView watingNoView;
			TextView resumeCheckView;

		};
	}

	// 이벤트
	// 예약 취소
	OnItemLongClickListener CancelReserveListener = new OnItemLongClickListener() {
		public boolean onItemLongClick(AdapterView<?> parent, View view,
				final int position, long id) {

			AlertDialog.Builder alert = new AlertDialog.Builder(
					ReserveListActivity.this);
			final TextView t = (TextView) view
					.findViewById(R.id.cName_textView);
			
			alert.setTitle("예약취소");
			alert.setMessage(t.getText().toString()+ "예약을 취소 하시겠습니까?");

			alert.setPositiveButton("삭제",
					new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog,
								int whichButton) {
				
							adapter.notifyDataSetChanged();

						}
					});
			alert.setNegativeButton("취소",
					new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog,
								int whichButton) {
						}
					});
			alert.show();
			return true;

		}
	};

	protected void onResume() {
		super.onResume();
		adapter.notifyDataSetChanged();
	}

	protected void onPause() {
		super.onPause();
	}
}
