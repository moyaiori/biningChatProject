package com.example.guidefair;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class TimetableActivity extends Activity {

	private String ip = "192.168.0.26";
	private String port = "8088";
	private String url = "http://" + ip + ":" + port
			+ "/GuideFair/App/controller_Timetable.jsp";

	private TimeTableAdapter adapter;
	ListView tListView;

	JSONObject jObject;
	JSONArray jArray;

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.timetable_list);

		tListView = (ListView) findViewById(R.id.timetableListView);
		// rListView.setOnItemLongClickListener(itemLongClickListener);
		// rListView.setOnItemClickListener(itemClickListener);
		adapter = new TimeTableAdapter(getBaseContext(),
				R.layout.timetable_list_row);

		TimeTableAsyncTask sendpostreq = new TimeTableAsyncTask();
		sendpostreq.execute("01090340302");

	}

	// 웹서버 통신(Post 방식)
	private class TimeTableAsyncTask extends AsyncTask<String, String, String> {

		protected String doInBackground(String... params) {
			String tel = params[0];

			Log.d("Timetable", "전화번호 : " + tel);

			HttpClient httpClient = SessionControl.getHttpClient();

			// 서버 접속
			HttpPost httpPost = new HttpPost(url);

			// post방식 (key,value)
			BasicNameValuePair p_tel = new BasicNameValuePair("p_tel", tel);

			List<NameValuePair> nameValuePairList = new ArrayList<NameValuePair>();
			nameValuePairList.add(p_tel);

			StringBuilder stringBuilder = new StringBuilder();

			// 서버로 데이터를 요청(Post방식)
			try {
				UrlEncodedFormEntity urlEncodedFormEntity = new UrlEncodedFormEntity(
						nameValuePairList, "UTF-8");
				httpPost.setEntity(urlEncodedFormEntity);

				//
				HttpResponse httpResponse = httpClient.execute(httpPost);
				HttpEntity entity = httpResponse.getEntity();
				InputStream inputStream = entity.getContent();
				InputStreamReader inputStreamReader = new InputStreamReader(
						inputStream);
				BufferedReader bufferedReader = new BufferedReader(
						inputStreamReader);

				String line = null;

				while ((line = bufferedReader.readLine()) != null) {
					stringBuilder.append(line);
				}

				Log.d("Timetable", "서버에서 받은 메세지 : " + stringBuilder.toString());

			} catch (Exception e) {
				Log.d("Timetable", "Exception : " + e.getMessage());
				e.printStackTrace();
			}

			return stringBuilder.toString();
		}

		//
		protected void onPostExecute(String result) {
			super.onPostExecute(result);

			// 서버로부터 요청받은 데이터를 JSON을 이용하여 데이터를 추출

			try {

				jObject = new JSONObject(result);
				jArray = jObject.getJSONArray("Timetable");

				tListView.setAdapter(adapter);

			} catch (JSONException e) {
				Log.d("Timetable", "Exception : " + e.getMessage());
				e.printStackTrace();
			}

		}
	}

	// 예약 리스트 어댑터
	public class TimeTableAdapter extends BaseAdapter {
		Context my_context;
		private int mRowLayout;

		public TimeTableAdapter(Context context, int layout) {
			my_context = context;
			mRowLayout = layout;
		}

		public Object getItem(int position) {
			return null;
		}

		public long getItemId(int position) {
			return position;
		}

		public int getCount() {
			return jArray.length();
		}

		public View getView(int position, View convertView, ViewGroup parent) {
			ReserveListViewHolder viewHolder;

			// currentCursor.moveToPosition(position);

			if (convertView == null) {
				LayoutInflater inflater = (LayoutInflater) my_context
						.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				convertView = inflater.inflate(mRowLayout, parent, false);

				viewHolder = new ReserveListViewHolder();

				viewHolder.cNameView = (TextView) convertView
						.findViewById(R.id.T_cName_textView);
				viewHolder.tNameView = (TextView) convertView
						.findViewById(R.id.T_tName_textView);
				viewHolder.pReserveView = (TextView) convertView
						.findViewById(R.id.T_pReserve_textView);
				viewHolder.pSeatiew = (TextView) convertView
						.findViewById(R.id.T_pSeat_textView);
				viewHolder.pEntryView = (TextView) convertView
						.findViewById(R.id.T_pEntry_textView);
				viewHolder.tStieView = (TextView) convertView
						.findViewById(R.id.T_tSite_textView);

				convertView.setTag(viewHolder);
			} else {
				viewHolder = (ReserveListViewHolder) convertView.getTag();
			}

			try {
				JSONObject jo = jArray.getJSONObject(position);

				viewHolder.cNameView.setText(jo.getString("cName"));
				viewHolder.tNameView.setText(jo.getString("tName"));
				viewHolder.pReserveView.setText(jo.getString("pReserve"));
				viewHolder.pSeatiew.setText(jo.getString("pSeat"));
				viewHolder.pEntryView.setText(jo.getString("pEntry"));
				viewHolder.tStieView.setText(jo.getString("tStie"));

			} catch (JSONException e) {
				Log.d("TimeTable", "Exception : " + e.getMessage());
				e.printStackTrace();
			}

			return convertView;
		}

		private class ReserveListViewHolder {
			// 기업명, 강의명, 예약인원, 입장인원, 강의인원, 강의장소
			// 시간

			TextView cNameView;
			TextView tNameView;
			TextView pReserveView;
			TextView pSeatiew;
			TextView pEntryView;
			TextView tStieView;

		};
	}

	protected void onResume() {
		super.onResume();
		adapter.notifyDataSetChanged();
	}

	protected void onPause() {
		super.onPause();
	}
}
