package com.example.guidefair;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.IntentFilter.MalformedMimeTypeException;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class ReadNFCTag extends Activity {

	private String ip = "192.168.0.26";
	private String port = "8088";
	private String url = "http://" + ip + ":" + port
			+ "/GuideFair/App/controller_NFCTag.jsp";


	private boolean mResumed = false;
	
	private boolean mWriteMode = false;
	NfcAdapter mNfcAdapter; // NFC 어댑터
	Intent mIntent; //
	PendingIntent mNfcPendingIntent;
	IntentFilter[] mWriteTagFilters;
	IntentFilter[] mNdefExchangeFilters;

	TextView mNote; // NFC태그로부터 읽어온 정보
	Button reserve_btn; // 부스 예약 버튼
	Button cancel_btn; // 취소 버튼

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.read_nfctag);

		// 시스템으로부터 NFC 어댑터를 얻는다.
		mNfcAdapter = NfcAdapter.getDefaultAdapter(getApplicationContext());

		mNote = (TextView) findViewById(R.id.readResult);

		// 예약 버튼 클릭 이벤트
		reserve_btn = (Button) findViewById(R.id.reserve_btn);
		reserve_btn.setOnClickListener(new OnClickListener() {
			public void onClick(View arg0) {
//				Toast.makeText(getApplication(), "예약 완료", Toast.LENGTH_SHORT)
//						.show();
				NFCTagAsyncTask sendpostreq = new NFCTagAsyncTask();
				sendpostreq.execute(mNote.getText().toString());

			}
		});

		// 취소 버튼 클릭 이벤트
		cancel_btn = (Button) findViewById(R.id.cancel_btn);
		cancel_btn.setOnClickListener(new OnClickListener() {
			public void onClick(View arg0) {
				finish();
			}
		});

		mNfcPendingIntent = PendingIntent.getActivity(this, 0, new Intent(this,
				MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
				0);

		// 태그로부터 텍스트를 읽기 위한 인텐트 필터를 동적으로 생성
		IntentFilter ndefDetected = new IntentFilter(
				NfcAdapter.ACTION_NDEF_DISCOVERED);
		try {
			ndefDetected.addDataType("text/plain");
		} catch (MalformedMimeTypeException e) {
			mNdefExchangeFilters = new IntentFilter[] { ndefDetected };
		}
	}

	// 태그 접촉시 어플 실행
	@Override
	protected void onResume() {
		super.onResume();
		mResumed = true;

		// 전경으로 왔을 때, 기다리고 있던 인텐트가 ACTION_NDEF_DISCOVERED인지를 체크
		if (NfcAdapter.ACTION_NDEF_DISCOVERED.contentEquals(getIntent()
				.getAction())) {
			NdefMessage[] messages = getNdefMessages(getIntent());
			byte[] payload = messages[0].getRecords()[0].getPayload();
			setNotBody(new String(payload));
			setIntent(new Intent());
		}
	}

	// 인텐트로부터 NdefMessage를 추출한다.
	private NdefMessage[] getNdefMessages(Intent intent) {
		NdefMessage[] msgs = null;
		String action = intent.getAction();

		if (NfcAdapter.ACTION_TECH_DISCOVERED.equals(action)
				|| NfcAdapter.ACTION_NDEF_DISCOVERED.equals(action)) {
			Parcelable[] rawMsgs = intent
					.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES);

			if (rawMsgs != null) {
				msgs = new NdefMessage[rawMsgs.length];
				for (int i = 0; i < rawMsgs.length; i++) {
					msgs[i] = (NdefMessage) rawMsgs[i];
				}
			} else {
				byte[] empty = new byte[] {};
				NdefRecord record = new NdefRecord(NdefRecord.TNF_UNCHANGED,
						empty, empty, empty);
				NdefMessage msg = new NdefMessage(new NdefRecord[] { record });
				msgs = new NdefMessage[] { msg };
			}
		} else {
			Log.d("NFC_TAG", "알려지지 않은 인텐트.");
			finish();
		}
		return msgs;
	}

	private void setNotBody(String string) {
		mNote.setText(string);
	}

	@Override
	protected void onPause() {
		super.onPause();
		mResumed = false;
		mNfcAdapter.disableForegroundNdefPush(this);
	}

	// NFC 태그 스캔시 호출되는 메소드
	@Override
	protected void onNewIntent(Intent intent) {
		super.onNewIntent(intent);

		// NFC 태그 읽기
		if (!mWriteMode
				&& NfcAdapter.ACTION_NDEF_DISCOVERED.equals(intent.getAction())) {
			NdefMessage[] msgs = getNdefMessages(intent);
		}
	}


	// 웹서버 통신(Post 방식) - 읽은 NFC 태그 값 전송
	private class NFCTagAsyncTask extends AsyncTask<String, String, String> {
		String req_code = "";

		protected String doInBackground(String... params) {
			String tag = params[0];

			Log.d("NFC_TAG", "태그 값 : " + tag);

			HttpClient httpClient = SessionControl.getHttpClient();

			// HttpClient httpClient = new DefaultHttpClient();

			// 객체 연결 설정 부분
			// HttpClient httpClient = SessionControl.getHttpClient();

			// 서버 접속
			HttpPost httpPost = new HttpPost(url);

			// post방식 (key,value)
			BasicNameValuePair nfcTag = new BasicNameValuePair("tag", tag);

			List<NameValuePair> nameValuePairList = new ArrayList<NameValuePair>();
			nameValuePairList.add(nfcTag);

			StringBuilder stringBuilder = new StringBuilder();

			// 서버로 데이터를 요청(Post방식)
			try {
				UrlEncodedFormEntity urlEncodedFormEntity = new UrlEncodedFormEntity(
						nameValuePairList, "UTF-8");
				httpPost.setEntity(urlEncodedFormEntity);

				//
				HttpResponse httpResponse = httpClient.execute(httpPost);
				HttpEntity entity = httpResponse.getEntity();
				InputStream inputStream = entity.getContent();
				InputStreamReader inputStreamReader = new InputStreamReader(
						inputStream);
				BufferedReader bufferedReader = new BufferedReader(
						inputStreamReader);

				String line = null;

				while ((line = bufferedReader.readLine()) != null) {
					stringBuilder.append(line);
				}

				Log.d("NFC_TAG", "서버에서 받은 메세지 : " + stringBuilder.toString());

			} catch (Exception e) {
				Log.d("NFC_TAG", "Exception : " + e.getMessage());
				e.printStackTrace();
			}

			// 서버로부터 요청받은 데이터를 JSON을 이용하여 데이터를 추출
			try {
				JSONObject jObject = new JSONObject(stringBuilder.toString());

				req_code = jObject.getString("nfcTagInfo");
				Log.d("NFC_TAG", "코드 : " + req_code);

			} catch (JSONException e) {
				Log.d("NFC_TAG", "Exception : " + e.getMessage());
				e.printStackTrace();
			}
			return stringBuilder.toString();
		}

		protected void onPostExecute(String result) {
			super.onPostExecute(result);

			Toast.makeText(getApplication(), req_code, Toast.LENGTH_SHORT)
					.show();

		}
	}

}
